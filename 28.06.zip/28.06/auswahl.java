import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.Scanner;

/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 24.06.2022
 * @author 
 */

public class auswahl extends JFrame {
  // Anfang Attribute
  private JButton bDrehen = new JButton();
  private JLabel pfeil = new JLabel();
    private ImageIcon pfeilDisabledIcon = new ImageIcon(getClass().getResource("images/pfeil.png"));
  private JTextField tfErgebnis = new JTextField();
  private JLabel jLabel1 = new JLabel();
  // Ende Attribute
  
  public auswahl() { 
    // Frame-Initialisierung
    super();
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    int frameWidth = 800; 
    int frameHeight = 600;
    setSize(frameWidth, frameHeight);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (d.width - getSize().width) / 2;
    int y = (d.height - getSize().height) / 2;
    setLocation(x, y);
    setLocationRelativeTo(null);
    setTitle("auswahl");
    setResizable(false);
    Container cp = getContentPane();
    cp.setLayout(null);
    // Anfang Komponenten
    tfErgebnis.setBounds(574, 434, 150, 20);
    tfErgebnis.setText("Ergebnis");
    cp.add(tfErgebnis);
    pfeil.setBounds(495, 224, 222, 100);
    pfeil.setText("");
    pfeil.setDisabledIcon(pfeilDisabledIcon);
    pfeil.setEnabled(false);
    pfeil.setOpaque(false);
    pfeil.setHorizontalAlignment(SwingConstants.CENTER);
    pfeil.setVisible(false);
    cp.add(pfeil);
    bDrehen.setBounds(315, 190, 171, 89);
    bDrehen.setText("Drehen");
    bDrehen.setMargin(new Insets(2, 2, 2, 2));
    bDrehen.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bDrehen_ActionPerformed(evt);
      }
    });
    cp.add(bDrehen);
    
    jLabel1.setBounds(632, 448, 9, 1);
    jLabel1.setText("text");
    cp.add(jLabel1);
    // Ende Komponenten
    
    setVisible(true);
  } // end of public auswahl
  
  // Anfang Methoden
  
  public static void main(String[] args) {
    new auswahl();
  } // end of main
  
  public void bDrehen_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    JFrame F = new JFrame();
  F.add(new roulette());
  F.setSize(350, 600);
  F.setVisible(true);
  F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  F.setLocationRelativeTo(null);
    pfeil.setVisible(true); 
  tfErgebnis.setText(roulette.gib() + "");  
  }
  
  // end of bDrehen_ActionPerformed

  // Ende Methoden
} // end of class auswahl
