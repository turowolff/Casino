import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 14.06.2022
 * @author 
 */

public class casino extends JFrame {
  // Anfang Attribute
  private JButton bRoulette = new JButton();
  private JButton bTicTacToe = new JButton();
  private JButton bLotto = new JButton();
  private JLabel lBild = new JLabel();
    public ImageIcon lBildDisabledIcon = new ImageIcon(getClass().getResource("images/bild.png"));
  private JButton bKartenspiel = new JButton();
  private JTextField Geld = new JTextField();
  private JNumberField jNumberField1 = new JNumberField();
  private JLabel lWievielGeldmoechtestdumitnehmen = new JLabel();
  // Ende Attribute
  
  public int mon = 1100;
  
  public casino() { 
    // Frame-Initialisierung
    super();
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    int frameWidth = 600; 
    int frameHeight = 600;
    setSize(frameWidth, frameHeight);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (d.width - getSize().width) / 2;
    int y = (d.height - getSize().height) / 2;
    setLocation(x, y);
    setTitle("casino");
    setResizable(false);
    Container cp = getContentPane();
    cp.setLayout(null);
    // Anfang Komponenten
    bKartenspiel.setBounds(245, 459, 90, 65);
    bKartenspiel.setText("Kartenspiel");
    bKartenspiel.setMargin(new Insets(2, 2, 2, 2));
    bKartenspiel.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bKartenspiel_ActionPerformed(evt);
      }
    });
    cp.add(bKartenspiel);
    lBild.setBounds(120, 166, 350, 273);
    lBild.setText("bild");
    lBild.setDisabledIcon(lBildDisabledIcon);
    lBild.setOpaque(false);
    lBild.setEnabled(false);
    cp.add(lBild);
    bLotto.setBounds(491, 42, 75, 65);
    bLotto.setText("Lotto");
    bLotto.setMargin(new Insets(2, 2, 2, 2));
    bLotto.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bLotto_ActionPerformed(evt);
      }
    });
    cp.add(bLotto);
    bTicTacToe.setBounds(244, 42, 99, 65);
    bTicTacToe.setText("Tic-Tac-Toe");
    bTicTacToe.setMargin(new Insets(2, 2, 2, 2));
    bTicTacToe.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bTicTacToe_ActionPerformed(evt);
      }
    });
    cp.add(bTicTacToe);
    bRoulette.setBounds(12, 42, 75, 65);
    bRoulette.setText("Roulette");
    bRoulette.setMargin(new Insets(2, 2, 2, 2));
    bRoulette.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bRoulette_ActionPerformed(evt);
      }
    });
    cp.add(bRoulette);
    cp.setBackground(new Color(0xFCA42C));
    Geld.setBounds(217, 11, 150, 20);
    Geld.setText(mon+"�");
    Geld.setEditable(false);
    Geld.setHorizontalAlignment(SwingConstants.CENTER);
    cp.add(Geld);
    jNumberField1.setBounds(255, 136, 75, 20);
    jNumberField1.setText("");
    cp.add(jNumberField1);
    lWievielGeldmoechtestdumitnehmen.setBounds(190, 112, 224, 20);
    lWievielGeldmoechtestdumitnehmen.setText("Wie viel Geld m�chtest du mitnehmen?");
    cp.add(lWievielGeldmoechtestdumitnehmen);
    // Ende Komponenten
    
    setVisible(true);
  } // end of public casino
  
  // Anfang Methoden
  
  public static void main(String[] args) {
    new casino();
  } // end of main
  
  public void bRoulette_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    //String[] arguments = new String[] {""};
    //roulette.main(arguments);
    JFrame F = new JFrame();
  F.add(new auswahl());
  F.setSize(600, 600);
  F.setVisible(true);
  F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    //bRoulette.setVisible(false);
  } // end of bRoulette_ActionPerformed

  public void bTicTacToe_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    
  } // end of bTicTacToe_ActionPerformed

  public void bLotto_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    String[] arguments = new String[] {"123"};
    lotto.main(arguments);
  } // end of bLotto_ActionPerformed

  public void bKartenspiel_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    String[] arguments = new String[] {"123"};
    Kartenspiel.main(arguments);
  } // end of bKartenspiel_ActionPerformed

  // Ende Methoden
} // end of class casino
