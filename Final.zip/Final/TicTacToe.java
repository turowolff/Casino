import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.ArrayList;
import java.util.Random;
/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 21.06.2022
 * @author 
 */

public class TicTacToe extends JFrame {
  // Anfang Attribute
  public static JButton b1 = new JButton();
  public static JButton b2 = new JButton();
  public static JButton b3 = new JButton();
  public static JButton b4 = new JButton();
  public static JButton b5 = new JButton();
  public static JButton b6 = new JButton();
  public static JButton b7 = new JButton();
  public static JButton b8 = new JButton();
  public static JButton b9 = new JButton();
  public static JLabel jLabel1 = new JLabel();
  public static JButton bStart = new JButton();
  private static JButton b100 = new JButton();
  private static JButton b50 = new JButton();
  private static JButton b150 = new JButton();
  private static JButton b200 = new JButton();
  private static JButton b250 = new JButton();
  // Ende Attribute
  
  public TicTacToe() { 
    // Frame-Initialisierung
    super();
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    int frameWidth = 600; 
    int frameHeight = 600;
    setSize(frameWidth, frameHeight);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (d.width - getSize().width) / 2;
    int y = (d.height - getSize().height) / 2;
    setLocation(x, y);
    setTitle("TicTacToe");
    setResizable(false);
    Container cp = getContentPane();
    cp.setLayout(null);
    // Anfang Komponenten
    b250.setBounds(64, 360, 75, 25);
    b250.setText("250");
    b250.setMargin(new Insets(2, 2, 2, 2));
    b250.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b250_ActionPerformed(evt);
      }
    });
    cp.add(b250);
    b200.setBounds(64, 328, 75, 25);
    b200.setText("200");
    b200.setMargin(new Insets(2, 2, 2, 2));
    b200.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b200_ActionPerformed(evt);
      }
    });
    cp.add(b200);
    b150.setBounds(64, 296, 75, 25);
    b150.setText("150");
    b150.setMargin(new Insets(2, 2, 2, 2));
    b150.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b150_ActionPerformed(evt);
      }
    });
    cp.add(b150);
    b50.setBounds(64, 264, 75, 25);
    b50.setText("50");
    b50.setMargin(new Insets(2, 2, 2, 2));
    b50.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b50_ActionPerformed(evt);
      }
    });
    cp.add(b50);
    b100.setBounds(64, 232, 75, 25);
    b100.setText("100");
    b100.setMargin(new Insets(2, 2, 2, 2));
    b100.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b100_ActionPerformed(evt);
      }
    });
    cp.add(b100);
    bStart.setBounds(216, 232, 155, 97);
    bStart.setText("Start");
    bStart.setMargin(new Insets(2, 2, 2, 2));
    bStart.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bStart_ActionPerformed(evt);
      }
    });
    bStart.setFont(new Font("Dialog", Font.BOLD, 50));
    bStart.setBackground(new Color(0x80FFFF));
    bStart.setVisible(true);
    cp.add(bStart);
    jLabel1.setBounds(240, 24, 110, 20);
    jLabel1.setText("");
    jLabel1.setVisible(true);
    cp.add(jLabel1);
    
    b1.setBounds(64, 80, 150, 150);
    b1.setText("");
    b1.setMargin(new Insets(2, 2, 2, 2));
    b1.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b1_ActionPerformed(evt);
      }
    });
    b1.setBackground(new Color(0xC1FFFF));
    b1.setFont(new Font("Dialog", Font.BOLD, 50));
    b1.setVisible(false);
    cp.add(b1);
    b2.setBounds(216, 80, 150, 150);
    b2.setText("");
    b2.setMargin(new Insets(2, 2, 2, 2));
    b2.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b2_ActionPerformed(evt);
      }
    });
    b2.setBackground(new Color(0xC1FFFF));
    b2.setFont(new Font("Dialog", Font.BOLD, 50));
    b2.setVisible(false);
    cp.add(b2);
    b3.setBounds(368, 80, 150, 150);
    b3.setText("");
    b3.setMargin(new Insets(2, 2, 2, 2));
    b3.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b3_ActionPerformed(evt);
      }
    });
    b3.setBackground(new Color(0xC1FFFF));
    b3.setFont(new Font("Dialog", Font.BOLD, 50));
    b3.setVisible(false);
    cp.add(b3);
    b4.setBounds(64, 232, 150, 150);
    b5.setBounds(216, 232, 150, 150);
    b6.setBounds(368, 232, 150, 150);
    b4.setText("");
    b4.setMargin(new Insets(2, 2, 2, 2));
    b4.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b4_ActionPerformed(evt);
      }
    });
    b4.setBackground(new Color(0xC1FFFF));
    b4.setFont(new Font("Dialog", Font.BOLD, 50));
    b4.setVisible(false);
    cp.add(b4);
    b5.setText("");
    b5.setMargin(new Insets(2, 2, 2, 2));
    b5.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b5_ActionPerformed(evt);
      }
    });
    b5.setBackground(new Color(0xC1FFFF));
    b5.setFont(new Font("Dialog", Font.BOLD, 50));
    b5.setVisible(false);
    cp.add(b5);
    b6.setText("");
    b6.setMargin(new Insets(2, 2, 2, 2));
    b6.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b6_ActionPerformed(evt);
      }
    });
    b6.setBackground(new Color(0xC1FFFF));
    b6.setFont(new Font("Dialog", Font.BOLD, 50));
    b6.setVisible(false);
    cp.add(b6);
    b7.setBounds(64, 384, 150, 150);
    b8.setBounds(216, 384, 150, 150);
    b9.setBounds(368, 384, 150, 150);
    b7.setText("");
    b7.setMargin(new Insets(2, 2, 2, 2));
    b7.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b7_ActionPerformed(evt);
      }
    });
    b7.setBackground(new Color(0xC1FFFF));
    b7.setFont(new Font("Dialog", Font.BOLD, 50));
    b7.setVisible(false);
    cp.add(b7);
    b8.setText("");
    b8.setMargin(new Insets(2, 2, 2, 2));
    b8.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b8_ActionPerformed(evt);
      }
    });
    b8.setBackground(new Color(0xC1FFFF));
    b8.setFont(new Font("Dialog", Font.BOLD, 50));
    b8.setVisible(false);
    cp.add(b8);
    b9.setText("");
    b9.setMargin(new Insets(2, 2, 2, 2));
    b9.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b9_ActionPerformed(evt);
      }
    });
    b9.setBackground(new Color(0xC1FFFF));
    b9.setFont(new Font("Dialog", Font.BOLD, 50));
    b9.setVisible(false);
    cp.add(b9);
    // Ende Komponenten
    
    setVisible(true);
  } // end of public TicTacToe
  
  public static boolean playerWin = false;
  public static boolean compWin = false;
  public static boolean hardMode = true;
  public static double einsatz = 0;
  
  // Anfang Methoden
  public static void game(){
    //while (game) { 
      if (hasWon("X")){
        playerWin = true;
      } else if (hasWon("O")){
        compWin = true;
      } else if (isDraw()) {
        restart();  
      }     
    //} // end of while
    if (playerWin) {
      gameDisable();
      jLabel1.setText("GEWONNEN!");
      casino.mon = casino.mon + einsatz * 0.2;
    } else if (compWin) {
      gameDisable();
      jLabel1.setText("VERLOREN :/");
      casino.mon = casino.mon - einsatz;
    } // end of if-else
  }
  public static void start(){
    bStart.setVisible(false);
    gameVisible();
    restart();
    fullGameReset();
        
  } 
  public static void main(String[] args){
    new TicTacToe();
  }
  
  public void b1_ActionPerformed(ActionEvent evt) {
    if (!b1.getText().equals("X") && !b1.getText().equals("O")){
      b1.setText("X");
      compMove();
      game();
    }
  } // end of b1_ActionPerformed

  public void b2_ActionPerformed(ActionEvent evt) {
    if (!b2.getText().equals("X") && !b2.getText().equals("O")){
      b2.setText("X");
      compMove();
      game();
    }
  } // end of b2_ActionPerformed

  public void b3_ActionPerformed(ActionEvent evt) {
    if (!b3.getText().equals("X") && !b3.getText().equals("O")){
      b3.setText("X");
      compMove();
      game();
    }
  } // end of b3_ActionPerformed

  public void b4_ActionPerformed(ActionEvent evt) {
    if (!b4.getText().equals("X") && !b4.getText().equals("O")){
      b4.setText("X");
      compMove();
      game();
    }
  } // end of b4_ActionPerformed

  public void b5_ActionPerformed(ActionEvent evt) {
    if (!b5.getText().equals("X") && !b5.getText().equals("O")){
      b5.setText("X");
      compMove();
      game();
    }
  } // end of b5_ActionPerformed

  public void b6_ActionPerformed(ActionEvent evt) {
    if (!b6.getText().equals("X") && !b6.getText().equals("O")){
      b6.setText("X");
      compMove();
      game();
    }
  } // end of b6_ActionPerformed

  public void b7_ActionPerformed(ActionEvent evt) {
    if (!b7.getText().equals("X") && !b7.getText().equals("O")){
      b7.setText("X");
      compMove();
      game();
    }
  } // end of b7_ActionPerformed

  public void b8_ActionPerformed(ActionEvent evt) {
    if (!b8.getText().equals("X") && !b8.getText().equals("O")){
      b8.setText("X");
      compMove();
      game();
    }
  } // end of b8_ActionPerformed

  public void b9_ActionPerformed(ActionEvent evt) {
    if (!b9.getText().equals("X") && !b9.getText().equals("O")){
      b9.setText("X");
      compMove();
      game();
    }
  } // end of b9_ActionPerformed
  
  public static void gameDisable() {
    b1.setEnabled(false);
    b2.setEnabled(false);
    b3.setEnabled(false);
    b4.setEnabled(false);
    b5.setEnabled(false);
    b6.setEnabled(false);
    b7.setEnabled(false);
    b8.setEnabled(false);
    b9.setEnabled(false);
  }
  public static void gameVisible() {
    b1.setVisible(true);
    b2.setVisible(true);
    b3.setVisible(true);
    b4.setVisible(true);
    b5.setVisible(true);
    b6.setVisible(true);
    b7.setVisible(true);
    b8.setVisible(true);
    b9.setVisible(true);
    }
  public static void compMove() {
    ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
    boolean strat1 = false;
    boolean strat2 = false;
    
    if (!b1.getText().equals("X") && !b1.getText().equals("O")){
      possibleMoves.add(1); 
    } else 
    if (!b2.getText().equals("X") && !b2.getText().equals("O")){
      possibleMoves.add(2); 
    }
    if (!b3.getText().equals("X") && !b3.getText().equals("O")){
      possibleMoves.add(3); 
    }
    if (!b4.getText().equals("X") && !b4.getText().equals("O")){
      possibleMoves.add(4); 
    }
    if (!b5.getText().equals("X") && !b5.getText().equals("O")){
      possibleMoves.add(5); 
    }
    if (!b6.getText().equals("X") && !b6.getText().equals("O")){
      possibleMoves.add(6); 
    }
    if (!b7.getText().equals("X") && !b7.getText().equals("O")){
      possibleMoves.add(7); 
    }
    if (!b8.getText().equals("X") && !b8.getText().equals("O")){
      possibleMoves.add(8); 
    }
    if (!b9.getText().equals("X") && !b9.getText().equals("O")){
      possibleMoves.add(9); 
    }
    if (canWinComp() > 0){
      for (int i = 0; i < possibleMoves.size(); i++){
        if (canWinComp() == possibleMoves.get(i)){
          if (possibleMoves.get(i) == 1) {
            b1.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 2) {
            b2.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 3) {
            b3.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 4) {
            b4.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 5) {
            b5.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 6) {
            b6.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 7) {
            b7.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 8) {
            b8.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 9) {
            b9.setText("O");
            break;
          }
          else{;}
        }
      } 
    }
    else if (canWin() > 0 && hardMode == true) {
      for (int i = 0; i < possibleMoves.size(); i++){
        if (canWin() == possibleMoves.get(i)){
          if (possibleMoves.get(i) == 1) {
            b1.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 2) {
            b2.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 3) {
            b3.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 4) {
            b4.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 5) {
            b5.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 6) {
            b6.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 7) {
            b7.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 8) {
            b8.setText("O");
            break;
          }
          else if (possibleMoves.get(i) == 9) {
            b9.setText("O");
            break;
          }
          else{;}
        }
      }
    } else {
      for (int i = 0; i < possibleMoves.size(); i++) {
        if (possibleMoves.get(i) == 5) {
          strat1 = true;
        } else {
          strat2 = true;  
        }
      }
      if (strat1 == true) {
        b5.setText("O");
      } else if (strat2) {
        int rnd = getRandom(possibleMoves);
        if (rnd == 1){
          b1.setText("O");
        }
        if (rnd == 3){
          b3.setText("O");
        }
        if (rnd == 7){
          b7.setText("O");
        }
        if (rnd == 9){
          b9.setText("O");
        }
        if (rnd == 2){
          b2.setText("O");
        } 
        if (rnd == 4){
          b4.setText("O");
        }
        if (rnd == 6){
          b6.setText("O");
        }
        if (rnd == 8){
          b8.setText("O"); 
        }  
      }
    }
  } 
  public static int getRandom(ArrayList<Integer> array) {
    int rnd = new Random().nextInt(array.size());
    return array.get(rnd);
  }
  public static int canWin(){
    if (b1.getText().equals("X") && b2.getText().equals("X") && !b3.getText().equals("X") && !b3.getText().equals("O")) {
      return 3;
    } // end of if
    else if (b1.getText().equals("X") && b4.getText().equals("X") && !b7.getText().equals("X") && !b7.getText().equals("O")) {
      return 7;
    }
    else if (b1.getText().equals("X") && b5.getText().equals("X") && !b9.getText().equals("X") && !b9.getText().equals("O")) {
      return 9;
    }
    else if (b1.getText().equals("X") && b2.getText().equals("X") && !b3.getText().equals("X") && !b3.getText().equals("O")) {
      return 3;
    }
    else if (b2.getText().equals("X") && b3.getText().equals("X") && !b1.getText().equals("X") && !b1.getText().equals("O")) {
      return 1;
    }
    else if (b2.getText().equals("X") && b5.getText().equals("X") && !b8.getText().equals("X") && !b8.getText().equals("O")) {
      return 8;
    }
    else if (b3.getText().equals("X") && b6.getText().equals("X") && !b9.getText().equals("X") && !b9.getText().equals("O")) {
      return 9;
    }
    else if (b4.getText().equals("X") && b7.getText().equals("X") && !b1.getText().equals("X") && !b1.getText().equals("O")) {
      return 1;
    } 
    else if (b4.getText().equals("X") && b5.getText().equals("X") && !b6.getText().equals("X") && !b6.getText().equals("O")) {
      return 6;
    } 
    else if (b5.getText().equals("X") && b6.getText().equals("X") && !b4.getText().equals("X") && !b4.getText().equals("O")) {
      return 4;
    }
    else if (b5.getText().equals("X") && b8.getText().equals("X") && !b3.getText().equals("X") && !b3.getText().equals("O")) {
      return 3;
    }
    else if (b5.getText().equals("X") && b7.getText().equals("X") && !b4.getText().equals("X") && !b4.getText().equals("O")) {
      return 4; 
    }
    else if (b5.getText().equals("X") && b9.getText().equals("X") && !b1.getText().equals("X") && !b1.getText().equals("O")) {
      return 1; 
    }
    else if (b7.getText().equals("X") && b8.getText().equals("X") && !b9.getText().equals("X") && !b9.getText().equals("O")) {
      return 9; 
    }
    else if (b9.getText().equals("X") && b8.getText().equals("X") && !b7.getText().equals("X") && !b7.getText().equals("O")) {
      return 7; 
    }
    else if (b1.getText().equals("X") && b7.getText().equals("X") && !b4.getText().equals("X") && !b4.getText().equals("O")) {
      return 4;
    }
    else if (b1.getText().equals("X") && b9.getText().equals("X") && !b5.getText().equals("X") && !b5.getText().equals("O")) {
      return 5;
    }
    else if (b4.getText().equals("X") && b6.getText().equals("X") && !b5.getText().equals("X") && !b5.getText().equals("O")) {
      return 5;
    }
    else if (b1.getText().equals("X") && b3.getText().equals("X") && !b2.getText().equals("X") && !b2.getText().equals("O")) {
      return 2;
    }
    else if (b7.getText().equals("X") && b9.getText().equals("X") && !b8.getText().equals("X") && !b8.getText().equals("O")) {
      return 8;
    }
    else if (b1.getText().equals("X") && b7.getText().equals("X") && !b4.getText().equals("X") && !b4.getText().equals("O")) {
      return 4;
    }
    else if (b9.getText().equals("X") && b3.getText().equals("X") && !b6.getText().equals("X") && !b6.getText().equals("O")) {
      return 6;
    }
    else if (b3.getText().equals("X") && b7.getText().equals("X") && !b5.getText().equals("X") && !b5.getText().equals("O")) {
      return 5;
    }
    else {return 0;}
  }
  public static int canWinComp(){
    if (b1.getText().equals("O") && b2.getText().equals("O") && !b3.getText().equals("O") && !b3.getText().equals("X")) {
      return 3;
    } // end of if
    else if (b1.getText().equals("O") && b4.getText().equals("O") && !b7.getText().equals("X") && !b7.getText().equals("O")) {
      return 7;
    }
    else if (b1.getText().equals("O") && b5.getText().equals("O") && !b9.getText().equals("X") && !b9.getText().equals("O")) {
      return 9;
    }
    else if (b1.getText().equals("O") && b2.getText().equals("O") && !b3.getText().equals("X") && !b3.getText().equals("O")) {
      return 3;
    }
    else if (b2.getText().equals("O") && b3.getText().equals("O") && !b1.getText().equals("X") && !b1.getText().equals("O")) {
      return 1;
    }
    else if (b2.getText().equals("O") && b5.getText().equals("O") && !b8.getText().equals("X") && !b8.getText().equals("O")) {
      return 8;
    }
    else if (b3.getText().equals("O") && b6.getText().equals("O") && !b9.getText().equals("X") && !b9.getText().equals("O")) {
      return 9;
    }
    else if (b4.getText().equals("O") && b7.getText().equals("O") && !b1.getText().equals("X") && !b1.getText().equals("O")) {
      return 1;
    } 
    else if (b4.getText().equals("O") && b5.getText().equals("O") && !b6.getText().equals("X") && !b6.getText().equals("O")) {
      return 6;
    } 
    else if (b5.getText().equals("O") && b6.getText().equals("O") && !b4.getText().equals("X") && !b4.getText().equals("O")) {
      return 4;
    }
    else if (b5.getText().equals("O") && b7.getText().equals("O") && !b3.getText().equals("X") && !b3.getText().equals("O")) {
      return 3;
    }
    else if (b5.getText().equals("O") && b7.getText().equals("O") && !b4.getText().equals("X") && !b4.getText().equals("O")) {
      return 4; 
    }
    else if (b5.getText().equals("O") && b9.getText().equals("O") && !b1.getText().equals("X") && !b1.getText().equals("O")) {
      return 1; 
    }
    else if (b7.getText().equals("O") && b8.getText().equals("O") && !b9.getText().equals("X") && !b9.getText().equals("O")) {
      return 9;
    }
    else if (b9.getText().equals("O") && b8.getText().equals("O") && !b7.getText().equals("X") && !b7.getText().equals("O")) {
      return 7; 
    }
    else if (b1.getText().equals("O") && b7.getText().equals("O") && !b4.getText().equals("X") && !b4.getText().equals("O")) {
      return 4;
    }
    else if (b1.getText().equals("O") && b9.getText().equals("O") && !b5.getText().equals("X") && !b5.getText().equals("O")) {
      return 5;
    }
    else if (b4.getText().equals("O") && b6.getText().equals("O") && !b5.getText().equals("X") && !b5.getText().equals("O")) {
      return 5;
    }
    else if (b1.getText().equals("O") && b3.getText().equals("O") && !b2.getText().equals("X") && !b2.getText().equals("O")) {
      return 2;
    }
    else if (b7.getText().equals("O") && b9.getText().equals("O") && !b8.getText().equals("X") && !b8.getText().equals("O")) {
      return 8;
    }
    else if (b1.getText().equals("O") && b7.getText().equals("O") && !b4.getText().equals("X") && !b4.getText().equals("O")) {
      return 4;
    }
    else if (b9.getText().equals("O") && b3.getText().equals("O") && !b6.getText().equals("X") && !b6.getText().equals("O")) {
      return 6;
    }
    else if (b3.getText().equals("O") && b7.getText().equals("O") && !b5.getText().equals("X") && !b5.getText().equals("O")) {
      return 5;
    }
    else {return 0;}
  }   
  
  public static boolean hasWon(String x){
    if (b1.getText().equals(x)&& b2.getText().equals(x)&& b3.getText().equals(x)){
      return true;
    }
    else if (b4.getText().equals(x)&& b5.getText().equals(x)&& b6.getText().equals(x)){
      return true;
    }
    else if (b7.getText().equals(x)&& b8.getText().equals(x)&& b9.getText().equals(x)){
      return true;
    }
    else if (b1.getText().equals(x)&& b4.getText().equals(x)&& b7.getText().equals(x)){
      return true;
    }
    else if (b2.getText().equals(x)&& b5.getText().equals(x)&& b8.getText().equals(x)){
      return true;
    }
    else if (b3.getText().equals(x)&& b6.getText().equals(x)&& b9.getText().equals(x)){
      return true;
    }
    else if (b1.getText().equals(x)&& b5.getText().equals(x)&& b9.getText().equals(x)){
      return true;
    }
    else if (b3.getText().equals(x)&& b5.getText().equals(x)&& b7.getText().equals(x)){
      return true;
    }
    else return false;
  }
  public static boolean isDraw(){
    if (!b1.getText().equals("")&& !b2.getText().equals("")&& !b3.getText().equals("")&& !b4.getText().equals("")&& !b5.getText().equals("")&& !b6.getText().equals("")&& !b7.getText().equals("")&& !b8.getText().equals("")&& !b9.getText().equals(""))  {
      return true;
    } else {
      return false;
    } // end of if-else
  }
  public static void restart(){
    b1.setText("");
    b2.setText("");
    b3.setText("");
    b4.setText("");
    b5.setText("");
    b6.setText("");
    b7.setText("");
    b8.setText("");
    b9.setText("");
  }
  
  public void bStart_ActionPerformed(ActionEvent evt) {
    start();
    
  } // end of bStart_ActionPerformed
  
  public static void fullGameReset(){
    b1.setEnabled(true);
    b2.setEnabled(true);
    b3.setEnabled(true);
    b4.setEnabled(true);
    b5.setEnabled(true);
    b6.setEnabled(true);
    b7.setEnabled(true);
    b8.setEnabled(true);
    b9.setEnabled(true);
    playerWin = false;
    compWin = false;
  }

  public void b100_ActionPerformed(ActionEvent evt) {
    einsatz = 100;
    if (einsatz > casino.mon) {
      einsatz = casino.mon;
    } // end of if
    einsatzHide();
     
  } // end of b100_ActionPerformed

  public void b50_ActionPerformed(ActionEvent evt) {
    einsatz = 50;
    if (einsatz > casino.mon) {
      einsatz = casino.mon;
    } // end of if
    einsatzHide();
    
  } // end of b50_ActionPerformed

  public void b150_ActionPerformed(ActionEvent evt) {
    einsatz = 150;
    if (einsatz > casino.mon) {
      einsatz = casino.mon;
    } // end of if
    einsatzHide();
    
  } // end of b150_ActionPerformed

  public void b200_ActionPerformed(ActionEvent evt) {
    einsatz = 200;
    if (einsatz > casino.mon) {
      einsatz = casino.mon;
    } // end of if
    einsatzHide();
    
  } // end of b200_ActionPerformed

  public void b250_ActionPerformed(ActionEvent evt) {
    einsatz = 250;
    if (einsatz > casino.mon) {
      einsatz = casino.mon;
    } // end of if
    einsatzHide();
    
  } // end of b250_ActionPerformed
  
  public static void einsatzHide(){
    b100.setVisible(false);
    b150.setVisible(false);
    b200.setVisible(false);
    b250.setVisible(false);
    b50.setVisible(false);
  }
  // Ende Methoden
} // end of class TicTacToe
