import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 14.06.2022
 * @author 
 */

public class casino extends JFrame {
  // Anfang Attribute
  private JButton bRoulette = new JButton();
  private JButton bTicTacToe = new JButton();
  private JButton bLotto = new JButton();
  private JLabel lBild = new JLabel();
    public ImageIcon lBildDisabledIcon = new ImageIcon(getClass().getResource("images/bild.png"));
  private JButton bKartenspiel = new JButton();
  private JTextField Geld = new JTextField();
  private JButton b1000 = new JButton();
  private JLabel lKnopfdrueckenzumaktualisierendesGeldbetrags1 = new JLabel();
  // Ende Attribute
  
  public static double mon = 1000;
  
  public static int cool = 0;
  
  public static double geben(){
    return mon;
    } 
  
  public casino() { 
    // Frame-Initialisierung
    super();
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    int frameWidth = 600; 
    int frameHeight = 600;
    setSize(frameWidth, frameHeight);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (d.width - getSize().width) / 2;
    int y = (d.height - getSize().height) / 2;
    setLocation(x, y);
    setTitle("casino");
    setResizable(false);
    Container cp = getContentPane();
    cp.setLayout(null);
    // Anfang Komponenten
    lKnopfdrueckenzumaktualisierendesGeldbetrags1.setBounds(160, 112, 290, 20);
    lKnopfdrueckenzumaktualisierendesGeldbetrags1.setText("Knopf drücken zum aktualisieren des Geldbetrags:");
    cp.add(lKnopfdrueckenzumaktualisierendesGeldbetrags1);
    b1000.setBounds(256, 136, 75, 25);
    b1000.setText("1000");
    b1000.setMargin(new Insets(2, 2, 2, 2));
    b1000.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b1000_ActionPerformed(evt);
      }
    });
    cp.add(b1000);
    bKartenspiel.setBounds(245, 459, 90, 65);
    bKartenspiel.setText("Kartenspiel");
    bKartenspiel.setMargin(new Insets(2, 2, 2, 2));
    bKartenspiel.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bKartenspiel_ActionPerformed(evt);
      }
    });
    cp.add(bKartenspiel);
    lBild.setBounds(120, 166, 350, 273);
    lBild.setText("bild");
    lBild.setDisabledIcon(lBildDisabledIcon);
    lBild.setOpaque(false);
    lBild.setEnabled(false);
    cp.add(lBild);
    bLotto.setBounds(491, 42, 75, 65);
    bLotto.setText("Lotto");
    bLotto.setMargin(new Insets(2, 2, 2, 2));
    bLotto.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bLotto_ActionPerformed(evt);
      }
    });
    cp.add(bLotto);
    bTicTacToe.setBounds(244, 42, 99, 65);
    bTicTacToe.setText("Tic-Tac-Toe");
    bTicTacToe.setMargin(new Insets(2, 2, 2, 2));
    bTicTacToe.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bTicTacToe_ActionPerformed(evt);
      }
    });
    cp.add(bTicTacToe);
    bRoulette.setBounds(12, 42, 75, 65);
    bRoulette.setText("Roulette");
    bRoulette.setMargin(new Insets(2, 2, 2, 2));
    bRoulette.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bRoulette_ActionPerformed(evt);
      }
    });
    cp.add(bRoulette);
    cp.setBackground(new Color(0xFCA42C));
    Geld.setBounds(217, 11, 150, 20);
    Geld.setText(mon+"€");
    Geld.setEditable(false);
    Geld.setHorizontalAlignment(SwingConstants.CENTER);
    cp.add(Geld);
    // Ende Komponenten
    
    setVisible(true);
  } // end of public casino
  
  // Anfang Methoden
  
  public static void main(String[] args) {
    new casino();
  } // end of main
  
  public void bRoulette_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einfügen
    //String[] arguments = new String[] {""};
    //roulette.main(arguments);
    JFrame F = new JFrame();
  F.add(new auswahl());
  F.setSize(600, 600);
  F.setVisible(true);
  F.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    //bRoulette.setVisible(false);
  } // end of bRoulette_ActionPerformed

  public void bTicTacToe_ActionPerformed(ActionEvent evt) {
    /* String[] arguments = new String[] {"123"};
    TicTacToe.main(arguments);  */
    new TicTacToe();
    
  } // end of bTicTacToe_ActionPerformed

  public void bLotto_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einfügen
    String[] arguments = new String[] {"123"};
    lotto.main(arguments);
  } // end of bLotto_ActionPerformed

  public void bKartenspiel_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einfügen
    String[] arguments = new String[] {"123"};
    Kartenspiel.main(arguments);
  } // end of bKartenspiel_ActionPerformed
  
  public void b1000_ActionPerformed(ActionEvent evt) {
    b1000.setText("" + mon);    
  } // end of b1000_ActionPerformed

  // Ende Methoden
} // end of class casino
