import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.util.Scanner;

public class roulette extends JPanel {
  public static void main(String args[]){
  new roulette();  
  JFrame F = new JFrame();
  F.add(new roulette());
  F.setSize(600, 600);
  F.setVisible(true);
  F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
 
public static int geld(){
   Scanner test = new Scanner(System.in);
  int eing = test.nextInt();
  return eing;
  }

public int i = 0;

public static int konstZufZahl = 0;

public static void neueZufZahl(int range) {
  Random murks = new Random();
  if (range>0){
     konstZufZahl = murks.nextInt(range);
  }else{
    konstZufZahl = 42;
  }
}

public static int getZufZahl(){
  neueZufZahl(720);  
  return konstZufZahl;
  }
  
public static int lol = getZufZahl();
  
public static int gib(){
  return lol;
    }


public void paintComponent(Graphics g){  
    
  AffineTransform at = AffineTransform.getTranslateInstance(20, 120);
    
   BufferedImage scheibe = LoadImage("roulette.png");  
    
    
  at.rotate(Math.toRadians(i++), scheibe.getWidth()/2, scheibe.getHeight()/2);
    
    
  Graphics2D g2d = (Graphics2D) g;
    
  g2d.drawImage(scheibe, at, null);
  
    
  System.out.println(lol);
    
    do{
        repaint();
     }while(i > lol);  
        
  }
  
BufferedImage LoadImage(String FileName){
    
  BufferedImage img = null;
  
  try{  
  img = ImageIO.read(new File(FileName));
  }catch(IOException e) {
      
  }
    
  return img;
} 
 }
 