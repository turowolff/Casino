import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.Scanner;

/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 24.06.2022
 * @author 
 */

public class auswahl extends JFrame {
  // Anfang Attribute
  private JButton bDrehen = new JButton();
  private JLabel pfeil = new JLabel();
    private ImageIcon pfeilDisabledIcon = new ImageIcon(getClass().getResource("images/pfeil.png"));
  private JTextField tfErgebnis = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JNumberField geld = new JNumberField();
  private JButton b1 = new JButton();
  private JButton b2 = new JButton();
  private JButton b3 = new JButton();
  private JButton b4 = new JButton();
  private JButton b5 = new JButton();
  private JButton b6 = new JButton();
  private JButton b7 = new JButton();
  private JButton b8 = new JButton();
  private JButton b9 = new JButton();
  private JButton b10 = new JButton();
  private JButton b11 = new JButton();
  private JButton b12 = new JButton();
  private JButton b13 = new JButton();
  private JButton b14 = new JButton();
  private JButton b15 = new JButton();
  private JButton b16 = new JButton();
  private JButton b17 = new JButton();
  private JButton b18 = new JButton();
  private JButton b19 = new JButton();
  private JButton b20 = new JButton();
  private JButton b21 = new JButton();
  private JButton b22 = new JButton();
  private JButton b23 = new JButton();
  private JButton b24 = new JButton();
  private JButton b25 = new JButton();
  private JButton b26 = new JButton();
  private JButton b27 = new JButton();
  private JButton b28 = new JButton();
  private JButton b29 = new JButton();
  private JButton b30 = new JButton();
  private JButton b31 = new JButton();
  private JButton b32 = new JButton();
  private JButton b33 = new JButton();
  private JButton b34 = new JButton();
  private JButton b35 = new JButton();
  private JButton b0 = new JButton();
  private JLabel info = new JLabel();
  private JButton fuenfzigeuro = new JButton();
  private JButton hunderteuro = new JButton();
  private JButton zweihunderteuro = new JButton();
  private JLabel lAktuellesGuthaben = new JLabel();
  private JLabel lEinsatz = new JLabel();
  // Ende Attribute
  
  public int klicks = 0;
  
  public String eins = "";
  public String zwei = "";
  public String drei = "";
  
  public double aus = casino.geben();
  
  /*public int auszahlung(){
    if(eins.equals(erg) && zwei.equals(erg) && drei.equals(erg)){
      aus = casino.geben()*1.5;
      }else{
        aus = casino.geben();
      }
    } */
      
       
  
  public auswahl() { 
    // Frame-Initialisierung
    super();
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    int frameWidth = 800; 
    int frameHeight = 600;
    setSize(frameWidth, frameHeight);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (d.width - getSize().width) / 2;
    int y = (d.height - getSize().height) / 2;
    setLocation(x, y);
    setLocationRelativeTo(null);
    setTitle("auswahl");
    setResizable(false);
    Container cp = getContentPane();
    cp.setLayout(null);
    // Anfang Komponenten
    lEinsatz.setBounds(346, 299, 110, 20);
    lEinsatz.setText("Einsatz");
    lEinsatz.setHorizontalAlignment(SwingConstants.CENTER);
    cp.add(lEinsatz);
    lAktuellesGuthaben.setBounds(620, 447, 114, 20);
    lAktuellesGuthaben.setText("Aktuelles Guthaben");
    lAktuellesGuthaben.setHorizontalAlignment(SwingConstants.CENTER);
    cp.add(lAktuellesGuthaben);
    fuenfzigeuro.setBounds(312, 341, 171, 49);
    fuenfzigeuro.setText("50�");
    fuenfzigeuro.setMargin(new Insets(2, 2, 2, 2));
    fuenfzigeuro.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        fuenfzigeuro_ActionPerformed(evt);
      }
    });
    cp.add(fuenfzigeuro);
    info.setBounds(295, 2, 313, 164);
    info.setText("<html>W�hle drei der links aufgezeigten Felder und klicke auf 'Drehen'.<br/> Wenn du 1 dieser Zahlen triffst, erh�ltst du das 1,5-fache deines Geld zur�ck.<br/> Triffst du nichts, gehst du leer aus.</html");
    info.setVerticalAlignment(SwingConstants.BOTTOM);
    info.setVerticalTextPosition(SwingConstants.CENTER);
    cp.add(info);
    b0.setBounds(114, 9, 75, 57);
    b0.setText("0");
    b0.setMargin(new Insets(2, 2, 2, 2));
    b0.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b0_ActionPerformed(evt);
      }
    });
    b0.setBackground(new Color(0x008000));
    b0.setFont(new Font("Dialog", Font.BOLD, 12));
    b0.setForeground(Color.WHITE);
    cp.add(b0);
    b35.setBounds(205, 481, 51, 41);
    b35.setText("35");
    b35.setMargin(new Insets(2, 2, 2, 2));
    b35.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b35_ActionPerformed(evt);
      }
    });
    b35.setBackground(Color.BLACK);
    b35.setFont(new Font("Dialog", Font.BOLD, 12));
    b35.setForeground(Color.WHITE);
    cp.add(b35);
    b34.setBounds(135, 478, 51, 41);
    b34.setText("34");
    b34.setMargin(new Insets(2, 2, 2, 2));
    b34.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b34_ActionPerformed(evt);
      }
    });
    b34.setBackground(Color.RED);
    cp.add(b34);
    b33.setBounds(67, 476, 51, 41);
    b33.setText("33");
    b33.setMargin(new Insets(2, 2, 2, 2));
    b33.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b33_ActionPerformed(evt);
      }
    });
    b33.setBackground(Color.BLACK);
    b33.setFont(new Font("Dialog", Font.BOLD, 12));
    b33.setForeground(Color.WHITE);
    cp.add(b33);
    b32.setBounds(220, 433, 51, 41);
    b32.setText("32");
    b32.setMargin(new Insets(2, 2, 2, 2));
    b32.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b32_ActionPerformed(evt);
      }
    });
    b32.setBackground(Color.RED);
    cp.add(b32);
    b31.setBounds(157, 429, 51, 41);
    b31.setText("31");
    b31.setMargin(new Insets(2, 2, 2, 2));
    b31.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b31_ActionPerformed(evt);
      }
    });
    b31.setBackground(Color.BLACK);
    b31.setFont(new Font("Dialog", Font.BOLD, 12));
    b31.setForeground(Color.WHITE);
    cp.add(b31);
    b30.setBounds(96, 428, 51, 41);
    b30.setText("30");
    b30.setMargin(new Insets(2, 2, 2, 2));
    b30.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b30_ActionPerformed(evt);
      }
    });
    b30.setBackground(Color.RED);
    cp.add(b30);
    b29.setBounds(39, 430, 51, 41);
    b29.setText("29");
    b29.setMargin(new Insets(2, 2, 2, 2));
    b29.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b29_ActionPerformed(evt);
      }
    });
    b29.setBackground(Color.BLACK);
    b29.setFont(new Font("Dialog", Font.BOLD, 12));
    b29.setForeground(Color.WHITE);
    cp.add(b29);
    b28.setBounds(224, 381, 51, 41);
    b28.setText("28");
    b28.setMargin(new Insets(2, 2, 2, 2));
    b28.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b28_ActionPerformed(evt);
      }
    });
    b28.setBackground(Color.BLACK);
    b28.setFont(new Font("Dialog", Font.BOLD, 12));
    b28.setForeground(Color.WHITE);
    cp.add(b28);
    b27.setBounds(159, 380, 51, 41);
    b27.setText("27");
    b27.setMargin(new Insets(2, 2, 2, 2));
    b27.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b27_ActionPerformed(evt);
      }
    });
    b27.setBackground(Color.RED);
    cp.add(b27);
    b26.setBounds(96, 380, 51, 41);
    b26.setText("26");
    b26.setMargin(new Insets(2, 2, 2, 2));
    b26.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b26_ActionPerformed(evt);
      }
    });
    b26.setBackground(Color.BLACK);
    b26.setFont(new Font("Dialog", Font.BOLD, 12));
    b26.setForeground(Color.WHITE);
    cp.add(b26);
    b25.setBounds(36, 378, 51, 41);
    b25.setText("25");
    b25.setMargin(new Insets(2, 2, 2, 2));
    b25.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b25_ActionPerformed(evt);
      }
    });
    b25.setBackground(Color.RED);
    cp.add(b25);
    b24.setBounds(222, 327, 51, 41);
    b24.setText("24");
    b24.setMargin(new Insets(2, 2, 2, 2));
    b24.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b24_ActionPerformed(evt);
      }
    });
    b24.setBackground(Color.BLACK);
    b24.setFont(new Font("Dialog", Font.BOLD, 12));
    b24.setForeground(Color.WHITE);
    cp.add(b24);
    b23.setBounds(155, 327, 51, 41);
    b23.setText("23");
    b23.setMargin(new Insets(2, 2, 2, 2));
    b23.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b23_ActionPerformed(evt);
      }
    });
    b23.setBackground(Color.RED);
    cp.add(b23);
    b22.setBounds(94, 324, 51, 41);
    b22.setText("22");
    b22.setMargin(new Insets(2, 2, 2, 2));
    b22.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b22_ActionPerformed(evt);
      }
    });
    b22.setBackground(Color.BLACK);
    b22.setFont(new Font("Dialog", Font.BOLD, 12));
    b22.setForeground(Color.WHITE);
    cp.add(b22);
    b21.setBounds(35, 322, 51, 41);
    b21.setText("21");
    b21.setMargin(new Insets(2, 2, 2, 2));
    b21.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b21_ActionPerformed(evt);
      }
    });
    b21.setBackground(Color.RED);
    cp.add(b21);
    b20.setBounds(222, 275, 51, 41);
    b20.setText("20");
    b20.setMargin(new Insets(2, 2, 2, 2));
    b20.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b20_ActionPerformed(evt);
      }
    });
    b20.setBackground(Color.BLACK);
    b20.setFont(new Font("Dialog", Font.BOLD, 12));
    b20.setForeground(Color.WHITE);
    cp.add(b20);
    b19.setBounds(158, 271, 51, 41);
    b19.setText("19");
    b19.setMargin(new Insets(2, 2, 2, 2));
    b19.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b19_ActionPerformed(evt);
      }
    });
    b19.setBackground(Color.RED);
    cp.add(b19);
    b18.setBounds(96, 274, 51, 41);
    b18.setText("18");
    b18.setMargin(new Insets(2, 2, 2, 2));
    b18.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b18_ActionPerformed(evt);
      }
    });
    b18.setBackground(Color.RED);
    cp.add(b18);
    b17.setBounds(31, 272, 51, 41);
    b17.setText("17");
    b17.setMargin(new Insets(2, 2, 2, 2));
    b17.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b17_ActionPerformed(evt);
      }
    });
    b17.setBackground(Color.BLACK);
    b17.setFont(new Font("Dialog", Font.BOLD, 12));
    b17.setForeground(Color.WHITE);
    cp.add(b17);
    b16.setBounds(219, 224, 51, 41);
    b16.setText("16");
    b16.setMargin(new Insets(2, 2, 2, 2));
    b16.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b16_ActionPerformed(evt);
      }
    });
    b16.setBackground(Color.RED);
    cp.add(b16);
    b15.setBounds(158, 225, 51, 41);
    b15.setText("15");
    b15.setMargin(new Insets(2, 2, 2, 2));
    b15.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b15_ActionPerformed(evt);
      }
    });
    b15.setBackground(Color.BLACK);
    b15.setFont(new Font("Dialog", Font.BOLD, 12));
    b15.setForeground(Color.WHITE);
    cp.add(b15);
    b14.setBounds(96, 222, 51, 41);
    b14.setText("14");
    b14.setMargin(new Insets(2, 2, 2, 2));
    b14.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b14_ActionPerformed(evt);
      }
    });
    b14.setBackground(Color.RED);
    cp.add(b14);
    b13.setBounds(34, 221, 51, 41);
    b13.setText("13");
    b13.setMargin(new Insets(2, 2, 2, 2));
    b13.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b13_ActionPerformed(evt);
      }
    });
    b13.setBackground(Color.BLACK);
    b13.setFont(new Font("Dialog", Font.BOLD, 12));
    b13.setForeground(Color.WHITE);
    cp.add(b13);
    b12.setBounds(216, 176, 51, 41);
    b12.setText("12");
    b12.setMargin(new Insets(2, 2, 2, 2));
    b12.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b12_ActionPerformed(evt);
      }
    });
    b12.setBackground(Color.RED);
    cp.add(b12);
    b11.setBounds(159, 172, 51, 41);
    b11.setText("11");
    b11.setMargin(new Insets(2, 2, 2, 2));
    b11.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b11_ActionPerformed(evt);
      }
    });
    b11.setBackground(Color.BLACK);
    b11.setFont(new Font("Dialog", Font.BOLD, 12));
    b11.setForeground(Color.WHITE);
    cp.add(b11);
    b10.setBounds(97, 170, 51, 41);
    b10.setText("10");
    b10.setMargin(new Insets(2, 2, 2, 2));
    b10.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b10_ActionPerformed(evt);
      }
    });
    b10.setBackground(Color.BLACK);
    b10.setFont(new Font("Dialog", Font.BOLD, 12));
    b10.setForeground(Color.WHITE);
    cp.add(b10);
    b9.setBounds(35, 173, 51, 41);
    b9.setText("9");
    b9.setMargin(new Insets(2, 2, 2, 2));
    b9.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b9_ActionPerformed(evt);
      }
    });
    b9.setBackground(Color.RED);
    cp.add(b9);
    b8.setBounds(218, 123, 51, 41);
    b8.setText("8");
    b8.setMargin(new Insets(2, 2, 2, 2));
    b8.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b8_ActionPerformed(evt);
      }
    });
    b8.setBackground(Color.BLACK);
    b8.setFont(new Font("Dialog", Font.BOLD, 12));
    b8.setForeground(Color.WHITE);
    cp.add(b8);
    b7.setBounds(157, 122, 51, 41);
    b7.setText("7");
    b7.setMargin(new Insets(2, 2, 2, 2));
    b7.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b7_ActionPerformed(evt);
      }
    });
    b7.setBackground(Color.RED);
    cp.add(b7);
    b6.setBounds(96, 124, 51, 41);
    b6.setText("6");
    b6.setMargin(new Insets(2, 2, 2, 2));
    b6.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b6_ActionPerformed(evt);
      }
    });
    b6.setBackground(Color.BLACK);
    b6.setFont(new Font("Dialog", Font.BOLD, 12));
    b6.setForeground(Color.WHITE);
    cp.add(b6);
    b5.setBounds(37, 123, 51, 41);
    b5.setText("5");
    b5.setMargin(new Insets(2, 2, 2, 2));
    b5.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b5_ActionPerformed(evt);
      }
    });
    b5.setBackground(Color.RED);
    cp.add(b5);
    b4.setBounds(219, 76, 51, 41);
    b4.setText("4");
    b4.setMargin(new Insets(2, 2, 2, 2));
    b4.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b4_ActionPerformed(evt);
      }
    });
    b4.setBackground(Color.BLACK);
    b4.setFont(new Font("Dialog", Font.BOLD, 12));
    b4.setForeground(Color.WHITE);
    cp.add(b4);
    b3.setBounds(153, 75, 51, 41);
    b3.setText("3");
    b3.setMargin(new Insets(2, 2, 2, 2));
    b3.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b3_ActionPerformed(evt);
      }
    });
    b3.setBackground(Color.RED);
    cp.add(b3);
    b2.setBounds(96, 73, 51, 41);
    b2.setText("2");
    b2.setMargin(new Insets(2, 2, 2, 2));
    b2.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b2_ActionPerformed(evt);
      }
    });
    b2.setBackground(Color.BLACK);
    b2.setFont(new Font("Dialog", Font.BOLD, 12));
    b2.setForeground(Color.WHITE);
    cp.add(b2);
    b1.setBounds(36, 74, 51, 41);
    b1.setText("1");
    b1.setMargin(new Insets(2, 2, 2, 2));
    b1.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        b1_ActionPerformed(evt);
      }
    });
    b1.setBackground(Color.RED);
    cp.add(b1);
    geld.setBounds(615, 479, 131, 28);
    geld.setDouble(aus);
    geld.setEditable(true);
    cp.add(geld);
    tfErgebnis.setBounds(574, 330, 150, 20);
    tfErgebnis.setText("Ergebnis");
    cp.add(tfErgebnis);
    pfeil.setBounds(495, 224, 222, 100);
    pfeil.setText("");
    pfeil.setDisabledIcon(pfeilDisabledIcon);
    pfeil.setEnabled(false);
    pfeil.setOpaque(false);
    pfeil.setHorizontalAlignment(SwingConstants.CENTER);
    pfeil.setVisible(false);
    cp.add(pfeil);
    bDrehen.setBounds(315, 190, 171, 89);
    bDrehen.setText("Drehen");
    bDrehen.setMargin(new Insets(2, 2, 2, 2));
    bDrehen.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        bDrehen_ActionPerformed(evt);
      }
    });
    bDrehen.setVisible(false);
    cp.add(bDrehen);
    
    jLabel1.setBounds(632, 448, 9, 1);
    jLabel1.setText("text");
    cp.add(jLabel1);
    hunderteuro.setBounds(312, 413, 171, 49);
    hunderteuro.setText("100�");
    hunderteuro.setMargin(new Insets(2, 2, 2, 2));
    hunderteuro.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        hunderteuro_ActionPerformed(evt);
      }
    });
    cp.add(hunderteuro);
    zweihunderteuro.setBounds(312, 485, 171, 49);
    zweihunderteuro.setText("200�");
    zweihunderteuro.setMargin(new Insets(2, 2, 2, 2));
    zweihunderteuro.addActionListener(new ActionListener() { 
      public void actionPerformed(ActionEvent evt) { 
        zweihunderteuro_ActionPerformed(evt);
      }
    });
    cp.add(zweihunderteuro);
    // Ende Komponenten
    
    setVisible(true);
  } // end of public auswahl
  
  // Anfang Methoden
  
  public static void main(String[] args) {
    new auswahl();
  } // end of main
  
  public String ergebnis(){
    String erg = "Error";  
  if (roulette.gib() == 0 || roulette.gib() == 360 || roulette.gib() == 720 || roulette.gib() == 1 || roulette.gib() == 361 || roulette.gib() == 2 || roulette.gib() == 362 || roulette.gib() == 3 || roulette.gib() == 363 || roulette.gib() == 4 || roulette.gib() == 364 || roulette.gib() == 5 || roulette.gib() == 365 || roulette.gib() == 6 || roulette.gib() == 366 || roulette.gib() == 7 || roulette.gib() == 367 || roulette.gib() == 8 || roulette.gib() == 368){
    erg = "Rot 34";
    }
  if (roulette.gib() == 9 || roulette.gib() == 369 || roulette.gib() == 10 || roulette.gib() == 370 || roulette.gib() == 11 || roulette.gib() == 371 || roulette.gib() == 12 || roulette.gib() == 372 || roulette.gib() == 13 || roulette.gib() == 373 || roulette.gib() == 14 || roulette.gib() == 374 || roulette.gib() == 15 || roulette.gib() == 375 || roulette.gib() == 16 || roulette.gib() == 376 || roulette.gib() == 17 || roulette.gib() == 377){
    erg = "Schwarz 17";
    }
  if (roulette.gib() == 18 || roulette.gib() == 378 || roulette.gib() == 19 || roulette.gib() == 379 || roulette.gib() == 20 || roulette.gib() == 380 || roulette.gib() == 21 || roulette.gib() == 381 || roulette.gib() == 22 || roulette.gib() == 382 || roulette.gib() == 23 || roulette.gib() == 383 || roulette.gib() == 24 || roulette.gib() == 384 || roulette.gib() == 25 || roulette.gib() == 385 || roulette.gib() == 26 || roulette.gib() == 386){
    erg = "Rot 25";
    }
  if (roulette.gib() == 27 || roulette.gib() == 387 || roulette.gib() == 28 || roulette.gib() == 388 || roulette.gib() == 29 || roulette.gib() == 389 || roulette.gib() == 30 || roulette.gib() == 390 || roulette.gib() == 31 || roulette.gib() == 391 || roulette.gib() == 32 || roulette.gib() == 392 || roulette.gib() == 33 || roulette.gib() == 393 || roulette.gib() == 34 || roulette.gib() == 394 || roulette.gib() == 35 || roulette.gib() == 395){
    erg = "Schwarz 2";
    }
  if (roulette.gib() == 36 || roulette.gib() == 396 || roulette.gib() == 37 || roulette.gib() == 397 || roulette.gib() == 38 || roulette.gib() == 398 || roulette.gib() == 39 || roulette.gib() == 399 || roulette.gib() == 40 || roulette.gib() == 400 || roulette.gib() == 41 || roulette.gib() == 401 || roulette.gib() == 42 || roulette.gib() == 402 || roulette.gib() == 43 || roulette.gib() == 403 || roulette.gib() == 44 || roulette.gib() == 404){
    erg = "Rot 21";
    }
  if (roulette.gib() == 45 || roulette.gib() == 405 || roulette.gib() == 46 || roulette.gib() == 406 || roulette.gib() == 47 || roulette.gib() == 407 || roulette.gib() == 48 || roulette.gib() == 408 || roulette.gib() == 49 || roulette.gib() == 409 || roulette.gib() == 50 || roulette.gib() == 410 || roulette.gib() == 51 || roulette.gib() == 411 || roulette.gib() == 52 || roulette.gib() == 412 || roulette.gib() == 53 || roulette.gib() == 413){
    erg = "Schwarz 4";
    }
  if (roulette.gib() == 54 || roulette.gib() == 414 || roulette.gib() == 55 || roulette.gib() == 415 || roulette.gib() == 56 || roulette.gib() == 416 || roulette.gib() == 57 || roulette.gib() == 417 || roulette.gib() == 58 || roulette.gib() == 418 || roulette.gib() == 59 || roulette.gib() == 419 || roulette.gib() == 60 || roulette.gib() == 420 || roulette.gib() == 61 || roulette.gib() == 421 || roulette.gib() == 62 || roulette.gib() == 422){
    erg = "Rot 19";
    }
  if (roulette.gib() == 63 || roulette.gib() == 423 || roulette.gib() == 64 || roulette.gib() == 424 || roulette.gib() == 65 || roulette.gib() == 425 || roulette.gib() == 66 || roulette.gib() == 426 || roulette.gib() == 67 || roulette.gib() == 427 || roulette.gib() == 68 || roulette.gib() == 428 || roulette.gib() == 69 || roulette.gib() == 429 || roulette.gib() == 70 || roulette.gib() == 430 || roulette.gib() == 71 || roulette.gib() == 431 || roulette.gib() == 72 || roulette.gib() == 432 || roulette.gib() == 73 || roulette.gib() == 433){
    erg = "Schwarz 15";
    }
  if (roulette.gib() == 74 || roulette.gib() == 434 || roulette.gib() == 75 || roulette.gib() == 435 || roulette.gib() == 76 || roulette.gib() == 436 || roulette.gib() == 77 || roulette.gib() == 437 || roulette.gib() == 78 || roulette.gib() == 438 || roulette.gib() == 79 || roulette.gib() == 439 || roulette.gib() == 80 || roulette.gib() == 440 || roulette.gib() == 81 || roulette.gib() == 441 || roulette.gib() == 82 || roulette.gib() == 442 || roulette.gib() == 83 || roulette.gib() == 443){
    erg = "Rot 32";
    }
  if (roulette.gib() == 84 || roulette.gib() == 444 || roulette.gib() == 85 || roulette.gib() == 445 || roulette.gib() == 86 || roulette.gib() == 446 || roulette.gib() == 87 || roulette.gib() == 447 || roulette.gib() == 88 || roulette.gib() == 448 || roulette.gib() == 89 || roulette.gib() == 449 || roulette.gib() == 90 || roulette.gib() == 450 || roulette.gib() == 91 || roulette.gib() == 451 || roulette.gib() == 92 || roulette.gib() == 452 || roulette.gib() == 93 || roulette.gib() == 453){
    erg = "Gr�n 0";
    }
  if (roulette.gib() == 94 || roulette.gib() == 454 || roulette.gib() == 95 || roulette.gib() == 455 || roulette.gib() == 96 || roulette.gib() == 456 || roulette.gib() == 97 || roulette.gib() == 457 || roulette.gib() == 98 || roulette.gib() == 458 || roulette.gib() == 99 || roulette.gib() == 459 || roulette.gib() == 100 || roulette.gib() == 460 || roulette.gib() == 101 || roulette.gib() == 461 || roulette.gib() == 102 || roulette.gib() == 462 || roulette.gib() == 103 || roulette.gib() == 463){
    erg = "Schwarz 26";
    }
  if (roulette.gib() == 104 || roulette.gib() == 464 || roulette.gib() == 105 || roulette.gib() == 465 || roulette.gib() == 106 || roulette.gib() == 466 || roulette.gib() == 107 || roulette.gib() == 467 || roulette.gib() == 108 || roulette.gib() == 468 || roulette.gib() == 109 || roulette.gib() == 469 || roulette.gib() == 110 || roulette.gib() == 470 || roulette.gib() == 111 || roulette.gib() == 471 || roulette.gib() == 112 || roulette.gib() == 472 || roulette.gib() == 113 || roulette.gib() == 473){
    erg = "Rot 3";
    }
  if (roulette.gib() == 114 || roulette.gib() == 474 || roulette.gib() == 115 || roulette.gib() == 475 || roulette.gib() == 116 || roulette.gib() == 476 || roulette.gib() == 117 || roulette.gib() == 477 || roulette.gib() == 118 || roulette.gib() == 478 || roulette.gib() == 119 || roulette.gib() == 479 || roulette.gib() == 120 || roulette.gib() == 480 || roulette.gib() == 121 || roulette.gib() == 481 || roulette.gib() == 122 || roulette.gib() == 482 || roulette.gib() == 123 || roulette.gib() == 483){
    erg = "Schwarz 35";
    }
  if (roulette.gib() == 124 || roulette.gib() == 484 || roulette.gib() == 125 || roulette.gib() == 485 || roulette.gib() == 126 || roulette.gib() == 486 || roulette.gib() == 127 || roulette.gib() == 487 || roulette.gib() == 128 || roulette.gib() == 488 || roulette.gib() == 129 || roulette.gib() == 489 || roulette.gib() == 130 || roulette.gib() == 490 || roulette.gib() == 131 || roulette.gib() == 491 || roulette.gib() == 132 || roulette.gib() == 492 || roulette.gib() == 133 || roulette.gib() == 493){
    erg = "Rot 12";
    }
  if (roulette.gib() == 134 || roulette.gib() == 494 || roulette.gib() == 135 || roulette.gib() == 495 || roulette.gib() == 136 || roulette.gib() == 496 || roulette.gib() == 137 || roulette.gib() == 497 || roulette.gib() == 138 || roulette.gib() == 498 || roulette.gib() == 139 || roulette.gib() == 499 || roulette.gib() == 140 || roulette.gib() == 500 || roulette.gib() == 141 || roulette.gib() == 501 || roulette.gib() == 142 || roulette.gib() == 502 || roulette.gib() == 143 || roulette.gib() == 503){
    erg = "Schwarz 28";
    }
  if (roulette.gib() == 144 || roulette.gib() == 504 || roulette.gib() == 145 || roulette.gib() == 505 || roulette.gib() == 146 || roulette.gib() == 506 || roulette.gib() == 147 || roulette.gib() == 507 || roulette.gib() == 148 || roulette.gib() == 508 || roulette.gib() == 149 || roulette.gib() == 509 || roulette.gib() == 150 || roulette.gib() == 510 || roulette.gib() == 151 || roulette.gib() == 511 || roulette.gib() == 152 || roulette.gib() == 512 || roulette.gib() == 153 || roulette.gib() == 513){
    erg = "Rot 7";
    }
  if (roulette.gib() == 154 || roulette.gib() == 514 || roulette.gib() == 155 || roulette.gib() == 515 || roulette.gib() == 156 || roulette.gib() == 516 || roulette.gib() == 157 || roulette.gib() == 517 || roulette.gib() == 158 || roulette.gib() == 518 || roulette.gib() == 159 || roulette.gib() == 519 || roulette.gib() == 160 || roulette.gib() == 520 || roulette.gib() == 161 || roulette.gib() == 521 || roulette.gib() == 162 || roulette.gib() == 522 || roulette.gib() == 163 || roulette.gib() == 523){
    erg = "Schwarz 29";
    }
  if (roulette.gib() == 164 || roulette.gib() == 524 || roulette.gib() == 165 || roulette.gib() == 525 || roulette.gib() == 166 || roulette.gib() == 526 || roulette.gib() == 167 || roulette.gib() == 527 || roulette.gib() == 168 || roulette.gib() == 528 || roulette.gib() == 169 || roulette.gib() == 529 || roulette.gib() == 170 || roulette.gib() == 530 || roulette.gib() == 171 || roulette.gib() == 531 || roulette.gib() == 172 || roulette.gib() == 532 || roulette.gib() == 173 || roulette.gib() == 533){
    erg = "Rot 18";
    }
  if (roulette.gib() == 174 || roulette.gib() == 534 || roulette.gib() == 175 || roulette.gib() == 535 || roulette.gib() == 176 || roulette.gib() == 536 || roulette.gib() == 177 || roulette.gib() == 537 || roulette.gib() == 178 || roulette.gib() == 538 || roulette.gib() == 179 || roulette.gib() == 539 || roulette.gib() == 180 || roulette.gib() == 540 || roulette.gib() == 181 || roulette.gib() == 541 || roulette.gib() == 182 || roulette.gib() == 542 || roulette.gib() == 183 || roulette.gib() == 543){
    erg = "Schwarz 22";
    }
  if (roulette.gib() == 184 || roulette.gib() == 544 || roulette.gib() == 185 || roulette.gib() == 545 || roulette.gib() == 186 || roulette.gib() == 546 || roulette.gib() == 187 || roulette.gib() == 547 || roulette.gib() == 188 || roulette.gib() == 548 || roulette.gib() == 189 || roulette.gib() == 549 || roulette.gib() == 190 || roulette.gib() == 550 || roulette.gib() == 191 || roulette.gib() == 551 || roulette.gib() == 192 || roulette.gib() == 552 || roulette.gib() == 193 || roulette.gib() == 553){
    erg = "Rot 9";
    }
  if (roulette.gib() == 194 || roulette.gib() == 554 || roulette.gib() == 195 || roulette.gib() == 555 || roulette.gib() == 196 || roulette.gib() == 556 || roulette.gib() == 197 || roulette.gib() == 557 || roulette.gib() == 198 || roulette.gib() == 558 || roulette.gib() == 199 || roulette.gib() == 559 || roulette.gib() == 200 || roulette.gib() == 560 || roulette.gib() == 201 || roulette.gib() == 561 || roulette.gib() == 202 || roulette.gib() == 562 || roulette.gib() == 203 || roulette.gib() == 563){
    erg = "Schwarz 31";
    }
  if (roulette.gib() == 204 || roulette.gib() == 564 || roulette.gib() == 205 || roulette.gib() == 565 || roulette.gib() == 206 || roulette.gib() == 566 || roulette.gib() == 207 || roulette.gib() == 567 || roulette.gib() == 208 || roulette.gib() == 568 || roulette.gib() == 209 || roulette.gib() == 569 || roulette.gib() == 210 || roulette.gib() == 570 || roulette.gib() == 211 || roulette.gib() == 571 || roulette.gib() == 212 || roulette.gib() == 572 || roulette.gib() == 213 || roulette.gib() == 573){
    erg = "Rot 14";
    }
  if (roulette.gib() == 214 || roulette.gib() == 574 || roulette.gib() == 215 || roulette.gib() == 575 || roulette.gib() == 216 || roulette.gib() == 576 || roulette.gib() == 217 || roulette.gib() == 577 || roulette.gib() == 218 || roulette.gib() == 578 || roulette.gib() == 219 || roulette.gib() == 579 || roulette.gib() == 220 || roulette.gib() == 580 || roulette.gib() == 221 || roulette.gib() == 581 || roulette.gib() == 222 || roulette.gib() == 582 || roulette.gib() == 223 || roulette.gib() == 583){
    erg = "Schwarz 20";
    }
  if (roulette.gib() == 224 || roulette.gib() == 584 || roulette.gib() == 225 || roulette.gib() == 585 || roulette.gib() == 226 || roulette.gib() == 586 || roulette.gib() == 227 || roulette.gib() == 587 || roulette.gib() == 228 || roulette.gib() == 588 || roulette.gib() == 229 || roulette.gib() == 589 || roulette.gib() == 230 || roulette.gib() == 590 || roulette.gib() == 231 || roulette.gib() == 591 || roulette.gib() == 232 || roulette.gib() == 592 || roulette.gib() == 233 || roulette.gib() == 593){
    erg = "Rot 1";
    }
  if (roulette.gib() == 234 || roulette.gib() == 594 || roulette.gib() == 235 || roulette.gib() == 595 || roulette.gib() == 236 || roulette.gib() == 596 || roulette.gib() == 237 || roulette.gib() == 597 || roulette.gib() == 238 || roulette.gib() == 598 || roulette.gib() == 239 || roulette.gib() == 599 || roulette.gib() == 240 || roulette.gib() == 600 || roulette.gib() == 241 || roulette.gib() == 601 || roulette.gib() == 242 || roulette.gib() == 602 || roulette.gib() == 243 || roulette.gib() == 603){
    erg = "Schwarz 33";
    }
  if (roulette.gib() == 244 || roulette.gib() == 604 || roulette.gib() == 245 || roulette.gib() == 605 || roulette.gib() == 246 || roulette.gib() == 606 || roulette.gib() == 247 || roulette.gib() == 607 || roulette.gib() == 248 || roulette.gib() == 608 || roulette.gib() == 249 || roulette.gib() == 609 || roulette.gib() == 250 || roulette.gib() == 610 || roulette.gib() == 251 || roulette.gib() == 611 || roulette.gib() == 252 || roulette.gib() == 612 || roulette.gib() == 253 || roulette.gib() == 613){
    erg = "Rot 16";
    }
  if (roulette.gib() == 254 || roulette.gib() == 614 || roulette.gib() == 255 || roulette.gib() == 615 || roulette.gib() == 256 || roulette.gib() == 616 || roulette.gib() == 257 || roulette.gib() == 617 || roulette.gib() == 258 || roulette.gib() == 618 || roulette.gib() == 259 || roulette.gib() == 619 || roulette.gib() == 260 || roulette.gib() == 620 || roulette.gib() == 261 || roulette.gib() == 621 || roulette.gib() == 262 || roulette.gib() == 622 || roulette.gib() == 263 || roulette.gib() == 623){
    erg = "Schwarz 24";
    }
  if (roulette.gib() == 264 || roulette.gib() == 624 || roulette.gib() == 265 || roulette.gib() == 625 || roulette.gib() == 266 || roulette.gib() == 626 || roulette.gib() == 267 || roulette.gib() == 627 || roulette.gib() == 268 || roulette.gib() == 628 || roulette.gib() == 269 || roulette.gib() == 629 || roulette.gib() == 270 || roulette.gib() == 630 || roulette.gib() == 271 || roulette.gib() == 631 || roulette.gib() == 272 || roulette.gib() == 632 || roulette.gib() == 273 || roulette.gib() == 633){
    erg = "Rot 5";
    }
  if (roulette.gib() == 274 || roulette.gib() == 634 || roulette.gib() == 275 || roulette.gib() == 635 || roulette.gib() == 276 || roulette.gib() == 636 || roulette.gib() == 277 || roulette.gib() == 637 || roulette.gib() == 278 || roulette.gib() == 638 || roulette.gib() == 279 || roulette.gib() == 639 || roulette.gib() == 280 || roulette.gib() == 640 || roulette.gib() == 281 || roulette.gib() == 641){
    erg = "Schwarz 10";
    }
  if (roulette.gib() == 282 || roulette.gib() == 642 || roulette.gib() == 283 || roulette.gib() == 643 || roulette.gib() == 284 || roulette.gib() == 644 || roulette.gib() == 285 || roulette.gib() == 645 || roulette.gib() == 286 || roulette.gib() == 646 || roulette.gib() == 287 || roulette.gib() == 647 || roulette.gib() == 288 || roulette.gib() == 648 || roulette.gib() == 289 || roulette.gib() == 649){
    erg = "Rot 23";
    }
  if (roulette.gib() == 290 || roulette.gib() == 650 || roulette.gib() == 291 || roulette.gib() == 651 || roulette.gib() == 292 || roulette.gib() == 652 || roulette.gib() == 293 || roulette.gib() == 653 || roulette.gib() == 294 || roulette.gib() == 654 || roulette.gib() == 295 || roulette.gib() == 655 || roulette.gib() == 296 || roulette.gib() == 656 || roulette.gib() == 297 || roulette.gib() == 657){
    erg = "Schwarz 8";
    }
  if (roulette.gib() == 298 || roulette.gib() == 658 || roulette.gib() == 299 || roulette.gib() == 659 || roulette.gib() == 300 || roulette.gib() == 660 || roulette.gib() == 301 || roulette.gib() == 661 || roulette.gib() == 302 || roulette.gib() == 662 || roulette.gib() == 303 || roulette.gib() == 663 || roulette.gib() == 304 || roulette.gib() == 664 || roulette.gib() == 305 || roulette.gib() == 665){
    erg = "Rot 38";
    }
  if (roulette.gib() == 306 || roulette.gib() == 666 || roulette.gib() == 307 || roulette.gib() == 667 || roulette.gib() == 308 || roulette.gib() == 668 || roulette.gib() == 309 || roulette.gib() == 669 || roulette.gib() == 310 || roulette.gib() == 670 || roulette.gib() == 311 || roulette.gib() == 671 || roulette.gib() == 312 || roulette.gib() == 672 || roulette.gib() == 313 || roulette.gib() == 673){
    erg = "Schwarz 11";
    }
  if (roulette.gib() == 314 || roulette.gib() == 674 || roulette.gib() == 315 || roulette.gib() == 675 || roulette.gib() == 316 || roulette.gib() == 676 || roulette.gib() == 317 || roulette.gib() == 677 || roulette.gib() == 318 || roulette.gib() == 678 || roulette.gib() == 319 || roulette.gib() == 679 || roulette.gib() == 320 || roulette.gib() == 680 || roulette.gib() == 321 || roulette.gib() == 681 || roulette.gib() == 322 || roulette.gib() == 682 || roulette.gib() == 323 || roulette.gib() == 683 ){
    erg = "Rot 36";
    }
  if (roulette.gib() == 324 || roulette.gib() == 684 || roulette.gib() == 325 || roulette.gib() == 685 || roulette.gib() == 326 || roulette.gib() == 686 || roulette.gib() == 327 || roulette.gib() == 687 || roulette.gib() == 328 || roulette.gib() == 688 || roulette.gib() == 329 || roulette.gib() == 689 || roulette.gib() == 330 || roulette.gib() == 690 || roulette.gib() == 331 || roulette.gib() == 691 ){
    erg = "Schwarz 13";
    }
  if (roulette.gib() == 332 || roulette.gib() == 692 || roulette.gib() == 333 || roulette.gib() == 693 || roulette.gib() == 334 || roulette.gib() == 694 || roulette.gib() == 335 || roulette.gib() == 695 || roulette.gib() == 336 || roulette.gib() == 696 || roulette.gib() == 337 || roulette.gib() == 697 || roulette.gib() == 338 || roulette.gib() == 698 || roulette.gib() == 339 || roulette.gib() == 699 || roulette.gib() == 340 || roulette.gib() == 700 || roulette.gib() == 341 || roulette.gib() == 701 ){
    erg = "Rot 21";
    }
  if (roulette.gib() == 342 || roulette.gib() == 702 || roulette.gib() == 343 || roulette.gib() == 703 || roulette.gib() == 344 || roulette.gib() == 704 || roulette.gib() == 345 || roulette.gib() == 705 || roulette.gib() == 346 || roulette.gib() == 706 || roulette.gib() == 347 || roulette.gib() == 707 || roulette.gib() == 348 || roulette.gib() == 708 || roulette.gib() == 349 || roulette.gib() == 709 ){
    erg = "Schwarz 5";
    }
  if (roulette.gib() == 350 || roulette.gib() == 710 || roulette.gib() == 351 || roulette.gib() == 711 || roulette.gib() == 352 || roulette.gib() == 712 || roulette.gib() == 353 || roulette.gib() == 713 || roulette.gib() == 354 || roulette.gib() == 714 || roulette.gib() == 355 || roulette.gib() == 715 || roulette.gib() == 356 || roulette.gib() == 716 || roulette.gib() == 357 || roulette.gib() == 717 || roulette.gib() == 358 || roulette.gib() == 718 || roulette.gib() == 359 || roulette.gib() == 719){
    erg = "Rot 34";
    }
                     
  tfErgebnis.setText(erg + "");
    return erg;
   }
  
  public void bDrehen_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    JFrame F = new JFrame();
  F.add(new roulette());
  F.setSize(350, 600);
  F.setVisible(true);
  F.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  F.setLocationRelativeTo(null);

    
    pfeil.setVisible(true);
    tfErgebnis.setText(ergebnis());
    if(eins.equals(ergebnis()) || zwei.equals(ergebnis()) || drei.equals(ergebnis())){
      aus = casino.geben() + (einsatz*3);
      }else{
        aus = casino.geben() - einsatz;
      }
    System.out.println(aus);
    geld.setDouble(aus);
 
  }
  
  
  // end of bDrehen_ActionPerformed

  public void b1_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b1.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 1";
      }
    if(klicks == 1){
      zwei = "Rot 1";
      }
    if(klicks == 2){
      drei = "Rot 1";
      }
  } // end of b1_ActionPerformed

  public void b2_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b2.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 2";
      }
    if(klicks == 1){
      zwei = "Schwarz 2";
      }
    if(klicks == 2){
      drei = "Schwarz 2";
      }
  } // end of b2_ActionPerformed

  public void b3_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b3.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 3";
      }
    if(klicks == 1){
      zwei = "Rot 3";
      }
    if(klicks == 2){
      drei = "Rot 3";
      }
  } // end of b3_ActionPerformed

  public void b4_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b4.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 4";
      }
    if(klicks == 1){
      zwei = "Schwarz 4";
      }
    if(klicks == 2){
      drei = "Schwarz 4";
      }
  } // end of b4_ActionPerformed

  public void b5_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b5.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 5";
      }
    if(klicks == 1){
      zwei = "Rot 5";
      }
    if(klicks == 2){
      drei = "Rot 5";
      }
  } // end of b5_ActionPerformed

  public void b6_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b6.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 6";
      }
    if(klicks == 1){
      zwei = "Schwarz 6";
      }
    if(klicks == 2){
      drei = "Schwarz 6";
      }
  } // end of b6_ActionPerformed

  public void b7_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b7.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 7";
      }
    if(klicks == 1){
      zwei = "Rot 7";
      }
    if(klicks == 2){
      drei = "Rot 7";
      }
  } // end of b7_ActionPerformed

  public void b8_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b8.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
      if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 8";
      }
    if(klicks == 1){
      zwei = "Schwarz 8";
      }
    if(klicks == 2){
      drei = "Schwarz 8";
      }
  } // end of b8_ActionPerformed

  public void b9_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b9.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 9";
      }
    if(klicks == 1){
      zwei = "Rot 9";
      }
    if(klicks == 2){
      drei = "Rot 9";
      }
  } // end of b9_ActionPerformed

  public void b10_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b10.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 10";
      }
    if(klicks == 1){
      zwei = "Schwarz 10";
      }
    if(klicks == 2){
      drei = "Schwarz 10";
      }
  } // end of b10_ActionPerformed

  public void b11_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b11.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 11";
      }
    if(klicks == 1){
      zwei = "Schwarz 11";
      }
    if(klicks == 2){
      drei = "Schwarz 11";
      }
  } // end of b11_ActionPerformed

  public void b12_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b12.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 12";
      }
    if(klicks == 1){
      zwei = "Rot 12";
      }
    if(klicks == 2){
      drei = "Rot 12";
      }
  } // end of b12_ActionPerformed

  public void b13_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b13.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 13";
      }
    if(klicks == 1){
      zwei = "Schwarz 13";
      }
    if(klicks == 2){
      drei = "Schwarz 13";
      }
  } // end of b13_ActionPerformed

  public void b14_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b14.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 14";
      }
    if(klicks == 1){
      zwei = "Rot 14";
      }
    if(klicks == 2){
      drei = "Rot 14";
      }
  } // end of b14_ActionPerformed

  public void b15_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b15.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 15";
      }
    if(klicks == 1){
      zwei = "Schwarz 15";
      }
    if(klicks == 2){
      drei = "Schwarz 15";
      }
  } // end of b15_ActionPerformed

  public void b16_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b16.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 16";
      }
    if(klicks == 1){
      zwei = "Rot 16";
      }
    if(klicks == 2){
      drei = "Rot 16";
      }
  } // end of b16_ActionPerformed

  public void b17_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b17.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 17";
      }
    if(klicks == 1){
      zwei = "Schwarz 17";
      }
    if(klicks == 2){
      drei = "Schwarz 17";
      }
  } // end of b17_ActionPerformed

  public void b18_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b18.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 18";
      }
    if(klicks == 1){
      zwei = "Rot 18";
      }
    if(klicks == 2){
      drei = "Rot 18";
      }
  } // end of b18_ActionPerformed

  public void b19_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b19.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 19";
      }
    if(klicks == 1){
      zwei = "Rot 19";
      }
    if(klicks == 2){
      drei = "Rot 19";
      }
  } // end of b19_ActionPerformed

  public void b20_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b20.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 20";
      }
    if(klicks == 1){
      zwei = "Schwarz 20";
      }
    if(klicks == 2){
      drei = "Schwarz 20";
      }
  } // end of b20_ActionPerformed

  public void b21_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b21.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 21";
      }
    if(klicks == 1){
      zwei = "Rot 21";
      }
    if(klicks == 2){
      drei = "Rot 21";
      }
  } // end of b21_ActionPerformed

  public void b22_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b22.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 22";
      }
    if(klicks == 1){
      zwei = "Schwarz 22";
      }
    if(klicks == 2){
      drei = "Schwarz 22";
      }
  } // end of b22_ActionPerformed

  public void b23_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b23.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 23";
      }
    if(klicks == 1){
      zwei = "Rot 23";
      }
    if(klicks == 2){
      drei = "Rot 23";
      }
  } // end of b23_ActionPerformed

  public void b24_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b24.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 24";
      }
    if(klicks == 1){
      zwei = "Schwarz 24";
      }
    if(klicks == 2){
      drei = "Schwarz 24";
      }
  } // end of b24_ActionPerformed

  public void b25_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b25.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 25";
      }
    if(klicks == 1){
      zwei = "Rot 25";
      }
    if(klicks == 2){
      drei = "Rot 25";
      }
  } // end of b25_ActionPerformed

  public void b26_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b26.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 26";
      }
    if(klicks == 1){
      zwei = "Schwarz 26";
      }
    if(klicks == 2){
      drei = "Schwarz 26";
      }
  } // end of b26_ActionPerformed

  public void b27_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b27.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 27";
      }
    if(klicks == 1){
      zwei = "Rot 27";
      }
    if(klicks == 2){
      drei = "Rot 27";
      }
  } // end of b27_ActionPerformed

  public void b28_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b28.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 28";
      }
    if(klicks == 1){
      zwei = "Schwarz 28";
      }
    if(klicks == 2){
      drei = "Schwarz 28";
      }
  } // end of b28_ActionPerformed

  public void b29_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b29.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 29";
      }
    if(klicks == 1){
      zwei = "Schwarz 29";
      }
    if(klicks == 2){
      drei = "Schwarz 29";
      }
  } // end of b29_ActionPerformed

  public void b30_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b30.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 30";
      }
    if(klicks == 1){
      zwei = "Rot 30";
      }
    if(klicks == 2){
      drei = "Rot 30";
      }
  } // end of b30_ActionPerformed

  public void b31_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b31.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 31";
      }
    if(klicks == 1){
      zwei = "Schwarz 31";
      }
    if(klicks == 2){
      drei = "Schwarz 31";
      }
  } // end of b31_ActionPerformed

  public void b32_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b32.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 32";
      }
    if(klicks == 1){
      zwei = "Rot 32";
      }
    if(klicks == 2){
      drei = "Rot 32";
      }
  } // end of b32_ActionPerformed

  public void b33_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b33.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 33";
      }
    if(klicks == 1){
      zwei = "Schwarz 33";
      }
    if(klicks == 2){
      drei = "Schwarz 33";
      }
  } // end of b33_ActionPerformed

  public void b34_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b34.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Rot 34";
      }
    if(klicks == 1){
      zwei = "Rot 34";
      }
    if(klicks == 2){
      drei = "Rot 34";
      }
  } // end of b34_ActionPerformed

  public void b35_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
     klicks++;
    b35.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Schwarz 35";
      }
    if(klicks == 1){
      zwei = "Schwarz 35";
      }
    if(klicks == 2){
      drei = "Schwarz 35";
      }
  } // end of b35_ActionPerformed

  public void b0_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    klicks++;
    b0.setVisible(false);
    if(klicks == 3){
      b1.setVisible(false);
      b2.setVisible(false);
      b3.setVisible(false);
      b4.setVisible(false);
      b5.setVisible(false);
      b6.setVisible(false);
      b7.setVisible(false);
      b8.setVisible(false);
      b9.setVisible(false);
      b10.setVisible(false);
      b11.setVisible(false);
      b12.setVisible(false);
      b13.setVisible(false);
      b14.setVisible(false);
      b15.setVisible(false);
      b16.setVisible(false);
      b17.setVisible(false);
      b18.setVisible(false);
      b19.setVisible(false);
      b20.setVisible(false);
      b21.setVisible(false);
      b22.setVisible(false);
      b23.setVisible(false);
      b24.setVisible(false);
      b25.setVisible(false);
      b26.setVisible(false);
      b27.setVisible(false);
      b28.setVisible(false);
      b29.setVisible(false);
      b30.setVisible(false);
      b31.setVisible(false);
      b32.setVisible(false);
      b33.setVisible(false);
      b34.setVisible(false);
      b35.setVisible(false);
      b0.setVisible(false);
      }
    if(wahl == 1 && klicks == 3){
      bDrehen.setVisible(true);
      }
    if(klicks == 0){
      eins = "Gr�n 0";
      }
    if(klicks == 1){
      zwei = "Gr�n 0";
      }
    if(klicks == 2){
      drei = "Gr�n 0";
      }
  } // end of b0_ActionPerformed
  
  public int einsatz = 0;
  
  public int wahl = 0;
  
  public void fuenfzigeuro_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    wahl++;
    
    if(casino.geben() >= 50){
      einsatz = 50;
      }
    
    if(klicks == 3){
      bDrehen.setVisible(true);
      }
    
    if(wahl == 1){
      fuenfzigeuro.setVisible(false);
      hunderteuro.setVisible(false);
      zweihunderteuro.setVisible(false);
      lEinsatz.setVisible(false);
      }
  } // end of fuenfzigeuro_ActionPerformed

  public void hunderteuro_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    wahl++;
    
    if(casino.geben() >= 100){
      einsatz = 100;
      }
    
    if(klicks == 3){
      bDrehen.setVisible(true);
      }
    
    if(wahl == 1){
      fuenfzigeuro.setVisible(false);
      hunderteuro.setVisible(false);
      zweihunderteuro.setVisible(false);
      lEinsatz.setVisible(false);
      }
  } // end of hunderteuro_ActionPerformed

  public void zweihunderteuro_ActionPerformed(ActionEvent evt) {
    // TODO hier Quelltext einf�gen
    wahl++;
    
    if(casino.geben() >= 200){
      einsatz = 200;
      }
    
    if(klicks == 3){
      bDrehen.setVisible(true);
      }
    
    if(wahl == 1){
      fuenfzigeuro.setVisible(false);
      hunderteuro.setVisible(false);
      zweihunderteuro.setVisible(false);
      lEinsatz.setVisible(false);
      }
  } // end of zweihunderteuro_ActionPerformed

  // Ende Methoden
} // end of class auswahl
